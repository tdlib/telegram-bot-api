import type {Env,TelegramUpdate} from '../telegram/types';
import {validateWebhookSecret,validateUpdateShape} from '../auth/authentication';
import {loadConfig} from '../config/config';
import {authorize} from '../auth/authorization';
import {enforceRateLimit} from '../auth/rate-limit';
import {telegram} from '../telegram/client';
import {routeUpdate} from '../router/update-router';
import {State} from '../state/kv';
import {logEvent} from '../utils/logging';
import {normalizeError} from '../utils/errors';

export async function handleWebhook(request:Request,env:Env){
  if(request.method==='GET' && new URL(request.url).pathname==='/health')return new Response('OK');
  const started=Date.now();
  if(request.method!=='POST')return new Response('Method Not Allowed',{status:405});
  if(!(request.headers.get('content-type')??'').toLowerCase().includes('application/json'))return new Response('Unsupported Media Type',{status:415});
  try{
    validateWebhookSecret(request,env);
    const body=await request.json();
    validateUpdateShape(body);
    const update=body as TelegramUpdate;
    const config=loadConfig(env);
    const actor=authorize(update,config);
    const state=new State(env.STATE);
    if(actor.userId!==undefined)await enforceRateLimit(state,`user:${actor.userId}`,config.rateLimitPerUser);
    if(actor.chatId!==undefined)await enforceRateLimit(state,`chat:${actor.chatId}`,config.rateLimitPerChat);
    await routeUpdate(update,telegram(env),config,state);
    logEvent({update_type:updateType(update),chat_id:actor.chatId,from_id:actor.userId,result:'ok',duration_ms:Date.now()-started});
    return new Response('OK');
  }catch(error){
    const e=normalizeError(error);
    logEvent({result:'error',error_classification:e.code,duration_ms:Date.now()-started});
    return new Response(e.status===429?'Too Many Requests':e.status===403?'Forbidden':'Bad Request',{status:e.status});
  }
}
function updateType(u:TelegramUpdate){if(u.callback_query)return 'callback_query';if(u.chat_join_request)return 'chat_join_request';if(u.edited_message)return 'edited_message';if(u.message)return 'message';return 'unknown';}
