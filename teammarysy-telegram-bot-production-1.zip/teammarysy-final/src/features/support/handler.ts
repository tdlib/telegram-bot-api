import type {TelegramUpdate} from '../../telegram/types';
import type {TelegramClient} from '../../telegram/client';
import type {Config} from '../../config/config';
import {State} from '../../state/kv';
import {nextId} from '../../state/counters';
import {getOpenTicketForChat,saveTicket} from '../../state/tickets';
import {supportAcknowledgement} from '../../telegram/messages';

function message(update:TelegramUpdate){return update.message??update.edited_message??update.callback_query?.message;}

export async function supportHandler(update:TelegramUpdate,bot:TelegramClient,c:Config,state?:State){
  const m=message(update);
  if(!m)return;
  if(!state){await bot.sendMessage(m.chat.id,supportAcknowledgement);return;}
  let ticket=await getOpenTicketForChat(state,m.chat.id);
  const isNew=!ticket;
  if(!ticket){
    const now=Date.now();
    ticket={id:nextId(state,'ticket'),chatId:m.chat.id,userId:m.from?.id??0,status:'open',lastActivity:now,createdAt:now};
    await saveTicket(state,ticket);
  }else{
    ticket.lastActivity=Date.now();
    await saveTicket(state,ticket);
  }
  if(isNew)await bot.sendMessage(m.chat.id,supportAcknowledgement);
  if(isNew&&c.supportAgentChatId)await bot.sendMessage(c.supportAgentChatId,`New support request ${ticket.id}\nChat: ${m.chat.id}\nUser: ${m.from?.id??'unknown'}`);
  if(isNew&&c.supportImageUrl)await bot.sendPhoto(m.chat.id,c.supportImageUrl);
}
